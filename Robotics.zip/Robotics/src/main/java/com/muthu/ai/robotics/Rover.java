package com.muthu.ai.robotics;

import com.muthu.ai.robotics.Position.Axis;
import com.muthu.ai.robotics.Position.Direction;

/**
 * Object represents the Mars Rover.
 * 
 * @author Samayan
 */
public class Rover {
	private PositionImpl position = null;

	// N - NORTH, E - EAST, W - WEST, S - SOUTH
	public enum Command {
		RIGHT, LEFT, MOVE;
		private void process(PositionImpl position) {
			switch (this) {
			case RIGHT:
				position.setDirectionRight();
				break;
			case LEFT:
				position.setDirectionLeft();
				break;
			case MOVE:
				switch (position.getDirection()) {
				case N:
					position.getY().increment();
					break;
				case E:
					position.getX().increment();
					break;
				case S:
					position.getY().decrement();
					break;
				case W:
					position.getX().decrement();
				}
			}
		}
	};

	public Rover(Axis x, Axis y, Direction direction) {
		this.position = new PositionImpl(x, y, direction);
	}

	public void processCommands(Command[] commands) {
		for (int i = 0; i < commands.length; i++) {
			commands[i].process(position);
		}
	}

	public Position getPosition() {
		return position;
	}
}
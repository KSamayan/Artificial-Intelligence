package com.muthu.ai.robotics;

/**
 * Position.java
 * Represents a location within a planet. It is intended to abstract away
 * implementation details.
 * 
 * @author Samayan
 */
public interface Position {

	public static final class Axis {
		int axis = 0;

		public Axis(int axis) {
			this.axis = axis;
		}

		protected void increment() {
			axis++;
		}

		protected void decrement() {
			axis--;
		}

		public int getAxis() {
			return axis;
		}
	}

	public enum Direction {
		// N - NORTH
		// E - EAST
		// W - WEST
		// S - SOUTH
		N {
			@Override
			public Direction right() {
				return E;
			}

			@Override
			public Direction left() {
				return W;
			}
		},

		E {
			@Override
			public Direction right() {
				return S;
			}

			@Override
			public Direction left() {
				return N;
			}
		},

		S {
			@Override
			public Direction right() {
				return W;
			}

			@Override
			public Direction left() {
				return E;
			}
		},

		W {
			@Override
			public Direction right() {
				return N;
			}

			@Override
			public Direction left() {
				return S;
			}
		};

		public abstract Direction right();

		public abstract Direction left();
	}

	public Axis getX();

	public Axis getY();

	public Direction getDirection();

	@Override
	public String toString();

}

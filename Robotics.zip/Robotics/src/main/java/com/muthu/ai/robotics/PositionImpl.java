package com.muthu.ai.robotics;

/**
 * Position.java
 * A class to implement PositionIf interface
 * 
 * @author Samayan
 */

public class PositionImpl implements Position {

	private Axis x = null;
	private Axis y = null;
	private Direction direction = null;

	public PositionImpl(Axis x, Axis y, Direction direction) {
		if (x == null || y == null || direction == null) {
			throw new IllegalArgumentException(
					"Position's attributes can't be null");
		}
		this.direction = direction;
		this.x = x;
		this.y = y;
	}

	protected void setDirectionRight() {
		direction = direction.right();
	}

	protected void setDirectionLeft() {
		direction = direction.left();
	}

	@Override
	public Axis getX() {
		return x;
	}

	@Override
	public Axis getY() {
		return y;
	}

	@Override
	public Direction getDirection() {
		return direction;
	}

	@Override
	public String toString() {
		return getX().getAxis() + " " + getY().getAxis() + " "
				+ getDirection().name();
	}

}

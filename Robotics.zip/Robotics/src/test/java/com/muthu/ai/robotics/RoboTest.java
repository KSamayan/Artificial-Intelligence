package com.muthu.ai.robotics;

import junit.framework.Assert;
import org.junit.*;
import com.muthu.ai.robotics.Position;
import com.muthu.ai.robotics.Rover;
import com.muthu.ai.robotics.Position.Direction;
import com.muthu.ai.robotics.Rover.Command;

/**
 * RoboTest.java 
 * Test Class 
 * Usage: mvn clean test -Dtest=com.muthu.ai.robotics.RoboTest
 * @author Samayan
 */
public class RoboTest {
	/**
	 * @param args - LMLMLMLMM, where L stands for LEFT, M for MOVE
	 */

 	@Test
    	public void testCase() {
        	Rover rover = new Rover(new Position.Axis(1),
				new Position.Axis(2), Direction.N);
		rover.processCommands(new Command[] { Command.LEFT, Command.MOVE,
				Command.LEFT, Command.MOVE, Command.LEFT, Command.MOVE,
				Command.LEFT, Command.MOVE, Command.MOVE });
		System.out.println(rover.getPosition());
        junit.framework.Assert.assertNotNull(rover.getPosition());
    	}

}
